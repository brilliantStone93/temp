package io;




public class ScoreMain {
	public static void main(String[] args) {
		new ScoreForm().event();
	}//main
}//
