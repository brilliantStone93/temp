package network;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;

public class ChatHandlerObject extends Thread{
	private Socket socket;
	private List<ChatHandlerObject> list;
	private ObjectInputStream oi;
	private ObjectOutputStream oo ;
	
	
	
	public ChatHandlerObject (Socket socket, List<ChatHandlerObject> list) throws IOException {
		this.socket = socket;
		this.list = list;
		
		oi = new ObjectInputStream(socket.getInputStream());
		oo = new ObjectOutputStream(socket.getOutputStream());
		
		
		
	}
	
	
	@Override
	public void run() {
	
		while(true) {
			//�г��� �޴���
			try {
				InfoDTO dto = (InfoDTO)oi.readObject();
				if(dto.getCommeand() == Info.JOIN) {
					
					broadcast(dto);
				}
				else if(dto.getCommeand() == Info.EXIT) {
						break; 
				}
				else if(dto.getCommeand() == Info.SEND) {
					broadcast(dto);
				}
				oi.close();
				oo.close();
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
			
				e.printStackTrace();
			}

		}//while
		
		
	}//run
	
	public void broadcast(InfoDTO dto) throws IOException {//�ٸ�����鿡�� �޼��� �ѷ��ִ� �޼ҵ�
		for(ChatHandlerObject ch : list) {
			ch.oo.writeObject(dto);
			ch.oo.flush();
		}
		
		
		
	}//boradcast
}
