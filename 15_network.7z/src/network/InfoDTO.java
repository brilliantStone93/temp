package network;

import java.io.Serializable;

enum Info{
	JOIN, EXIT, SEND
}

public class InfoDTO implements Serializable{
	//BufferedReader , printWriter ������� �ʴ´�
	//��ä(InfoDTO)�� �����͸� �ѱ�� �ް� 
	//ObjectInputStream, ObjectOutPutStream�� �����
	private String nickName;
	private String message;
	private Info commeand;
	
	
	
	//getter setter
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Info getCommeand() {
		return commeand;
	}
	public void setCommeand(Info commeand) {
		this.commeand = commeand;
	}
	
	
	
}
